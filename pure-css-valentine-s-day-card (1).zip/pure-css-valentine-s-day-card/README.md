# Pure CSS Valentine's Day Card

A Pen created on CodePen.

Original URL: [https://codepen.io/Allukats/pen/wBvabaa](https://codepen.io/Allukats/pen/wBvabaa).

